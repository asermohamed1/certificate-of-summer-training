#!/bin/bash

set -e

docker-entrypoint.sh mysqld &

sleep 10

mysql -u $MYSQL_USER -p$MYSQL_PASSWORD $MYSQL_DATABASE < /docker-entrypoint-initdb.d/init.sql

wait
